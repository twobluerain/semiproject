console.log("*****Review Module........");
function getList(param) {
     let contentsno = param.contentsno;
        return fetch('contents/detail/${contentsno}',{method:'get'}) 
              .then(response => response.json())
              .catch(console.log)
}
 
function getPage(param) {
    let url = `/contents/detail/page?${param}`;
console.log(url);
        return fetch(url,{method : 'get'})
              .then(response => response.text())
              .catch(console.log)
 
}

function add(review) {
        return fetch('contents/detail/${contentsno}',{
                method: 'post',
                body: JSON.stringify(review),
                headers: {'Content-Type': "application/json; charset=utf-8"}
                })
                .then(response => response.json())
                .catch(console.log);
}
 
function get(rnum) {
        return fetch(`/detail/${rnum}`,{method: 'get'})
               .then(response => response.json())
               .catch(console.log);
}