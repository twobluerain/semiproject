console.log("*****review Module........");
function getList(param) {
     let contentsno = param.contentsno;
         let sno = param.sno;
         let eno = param.eno;
        return fetch(`/contents/review/list/${contentsno}/${sno}/${eno}`,{method:'get'}) 
              .then(response => response.json())
              .catch(console.log)
}
 
function getPage(param) {
    let url = `/contents/review/page?${param}`;
console.log(url);
        return fetch(url,{method : 'get'})
              .then(response => response.text())
              .catch(console.log)
 
}

function add(review) {
        return fetch('contents/review/create',{
                method: 'post',
                body: JSON.stringify(review),
                headers: {'Content-Type': "application/json; charset=utf-8"}
                })
                .then(response => response.json())
                .catch(console.log);
}
 
function get(rnum) {
        return fetch(`/review/${rnum}`,{method: 'get'})
               .then(response => response.json())
               .catch(console.log);
}
console.log("*****Review Module........");
function getList(param) {
     let contentsno = param.contentsno;
         let sno = param.sno;
         let eno = param.eno;
        try {
        const response = await fetch(`/contents/review/list/${contentsno}/${sno}/${eno}`, { method: 'get' });
        return await response.json();
    } catch (data) {
        return console.log(data);
    }
}
 
function getPage(param) {
    let url = `/contents/review/page?${param}`;
console.log(url);
        return fetch(url,{method : 'get'})
              .then(response => response.text())
              .catch(console.log)
 
}