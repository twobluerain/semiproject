package com.study.model;

import lombok.Data;

@Data
public class ReplyDTO {
  private int rnum;
  private String content;
  private String regdate;
  private String id;
  private int contentsno;
}
